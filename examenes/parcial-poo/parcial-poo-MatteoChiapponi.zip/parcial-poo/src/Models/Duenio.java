package Models;

public class Duenio {
    private String nombre;
    private String apellido;
    private int cuit;

    public Duenio(String nombre, String apellido, int cuit) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.cuit = cuit;
    }
}
